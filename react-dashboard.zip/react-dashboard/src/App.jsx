import React, { useState, useEffect } from 'react';
import ParkingMap from './components/ParkingMap';
import spotsData from './data/spots.json';
import { fetchParkingSpot } from './api/parkingAPI';

function App() {
  const [statuses, setStatuses] = useState([]);

  useEffect(() => {
    let isMounted = true;
    const fetchData = async () => {
      try {
        const data = await fetchParkingSpot();
        if (isMounted) setStatuses(data);
      } catch (err) {
        console.error('Error fetching statuses:', err);
      }
    };

    fetchData();                                              // do it immediately
    const intervalId = setInterval(fetchData);        // , 5000 for every 5 seoconds RIGHT NOW SET TO 0 SECOND TIME INTERVAL
    return () => {
      isMounted = false;
      clearInterval(intervalId);
    };
  }, []);

  return (
    <div style={{ padding: 20 }}>
      <h1>My Parking Map</h1>
      <ParkingMap
        spotsData={spotsData}
        statuses={statuses}
        width={1874}
        height={1218}
      />
    </div>
  );
}

export default App;
